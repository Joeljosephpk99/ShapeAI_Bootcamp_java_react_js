import React from "react";

function Note() {
return (
  <div className="note">
    <h1>javascript and react.js</h1>
    <p> this is amazing bootcamp</p>
    </div>

);
}

export default Note